for user login sample email id and password is written below even if you are new user you can signup by clicking 
on signub button on welcome page

sample user
email : test@gmail.com
password : abcd

sample admin login
email : test@gmail.com
password : abcd

the app will run on local host 
port : 5000

there are various folder  and files like
static :stores static pages
templates : stores html templates for whole operation
instance ; stores database for whole operation
env : stores environment files
webapp.py : main python app
project documentation : project_documentation


some sample products and sample sample categories are already added