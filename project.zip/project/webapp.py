from flask import Flask , render_template , request , redirect , session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'abcd'
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///userdata.db"
db = SQLAlchemy(app)
app.app_context().push()

class Userdata(db.Model):
    sno = db.Column(db.Integer , primary_key = True )
    name = db.Column(db.String(30))
    email = db.Column(db.String(30))
    passw = db.Column(db.String(30))
    mobile = db.Column(db.Integer)

    def __repr__(self) -> str:
        return f"{self.name} - {self.email} - {self.passw} - {self.mobile}"
    def __logv__(self) -> str:
        return f"{self.email} - {self.passw}"

class Admindata(db.Model):
    Aid = db.Column(db.String(30) , primary_key = True )
    name = db.Column(db.String(30))
    email = db.Column(db.String(30))
    add = db.Column(db.String(200))
    mobile = db.Column(db.Integer)
    passw = db.Column(db.String(30))
    

    def __repr__(self) -> str:
        return f"{self.name} - {self.email} - {self.passw} - {self.mobile}"

class Od(db.Model):

    orderid = db.Column(db.Integer , primary_key = True)
    name = db.Column(db.String(30))
    address = db.Column(db.String(300))
    mobile = db.Column(db.Integer)
    item = db.Column(db.String(30))
    pid = db.Column(db.String(30))
    qty = db.Column(db.Integer)
    ottl = db.Column(db.Integer)
    payment_method = db.Column(db.String(20))

    def __repr__(self) -> str:
        return f"{self.orderid} - {self.name} - {self.address} - {self.mobile} - {self.item} - {self.cname} - {self.qty}"

class Product(db.Model):
    pid = db.Column(db.String(30) , primary_key = True )
    cid = db.Column(db.String(30))
    pname = db.Column(db.String(30))
    mnfdt = db.Column(db.String(20))
    expdt = db.Column(db.String(20))
    rate = db.Column(db.Integer)
    unit = db.Column(db.String(20))

    def __repr__(self) -> str:
        return f"{self.pid} - {self.cid} - {self.pname} - {self.mnfdt} - {self.expdt} - {self.rate} - {self.unit}"

class Category(db.Model):
    cid = db.Column(db.String(30) , primary_key =True)
    cname = db.Column(db.String(30))

    def __repr__(self) -> str:
        return f"{self.cid} - {self.cname}"
    
class Orderlog(db.Model):
    pid = db.Column(db.Integer , primary_key =True)
    rate = db.Column(db.Integer)
    qty = db.Column(db.Integer)
    itemttl = db.Column(db.Integer)

    def __repr__(self) -> str:
        return f"{self.cid} - {self.cname}"

class Corder(db.Model):
    orderid = db.Column(db.Integer , primary_key = True )
    name = db.Column(db.String(30))
    address = db.Column(db.String(300))
    item = db.Column(db.String(30))
    pid = db.Column(db.String(30))
    mobile = db.Column(db.Integer)
    qty = db.Column(db.Integer)
    ottl = db.Column(db.Integer)
    ocd = db.Column(db.DateTime , default = datetime.utcnow)

    def __repr__(self) -> str:
        return f"{self.orderid} - {self.name} - {self.address} - {self.item} - {self.qty}"

@app.route('/alogin')
def alogin():
    return render_template("alogin.html")

@app.route("/products")
def showproducts():
    allp = Product.query.all()
    allc = Category.query.all()
    alli = Orderlog.query.all()
    l=[]
    for x in alli:
        l.append(str(x.pid))
    return render_template("products.html" , allc = allc , allp = allp , l=l , alli=alli)

@app.route("/show")
def od():
    allud = Userdata.query.all()
    print(allud)
    return "this is a order page"

@app.route('/adbrd')
def adbrd():
    return render_template('adbrd.html')

@app.route("/aloginv" , methods = ['POST'])
def alogin_verify():
    

    aid = request.form['aid']
    tpassw = request.form['passw']
    
    udd = Admindata.query.all()
    for x in udd:
        print(x.email , x.passw)
        if x.email == aid and x.passw == tpassw :
            return redirect('/adbrd')
        
    return "invalid email or password please go back and try again"

@app.route("/addnp" , methods = ["POST"])
def addnp():
    npid = request.form['pid']
    ncid = request.form['cid']
    npname = request.form['name']
    nmnfdt = request.form['mnfdt']
    nexpdt = request.form['expdt']
    nrate = request.form['rate']
    nunit = request.form['unit']
    
    qp = Product.query.all()
    for x in qp:
        if x.pid == npid:
            return F"product with same product id already exist please go back and add product with different product id"
    np = Product(pid = npid , cid = ncid , pname = npname , mnfdt = nmnfdt , expdt = nexpdt , rate = nrate , unit = nunit)
    db.session.add(np)
    db.session.commit()
    return redirect("/addp")

@app.route("/addp")
def addp():
    allp = Product.query.all()
    allc = Category.query.all()
    
    return render_template("addp.html" , allp = allp , allc = allc)

@app.route("/addc")
def addc():
    allc = Category.query.all()
    return render_template("addc.html" , allc = allc)
    
@app.route("/addnc" , methods = ["POST"])
def addnc():
    ncid = request.form['cid']
    ncname = request.form['cname']
    qc = Category.query.all()
    for x in qc:
        if ncid == x.cid:
            return f"category with same category id exist please go back and add category with different category id "
    
    nc = Category(cid = ncid , cname = ncname )
    db.session.add(nc)
    db.session.commit()
    return redirect('/addc')

@app.route("/")
def welcome():
    return render_template("welcome.html")

@app.route("/submit_form" , methods = ['POST'])
def submit_form():
    name = request.form['name']
    email = request.form['email']
    passw = request.form['passw']
    mobile = request.form['mobile']
    user = Userdata(name = name , email = email , passw = passw , mobile = mobile)
    db.session.add(user)
    db.session.commit()
    return redirect('/')

@app.route("/atc/<int:pid>/<int:rate>")
def adtc(pid,rate):
    oll=[]
    codl = Orderlog.query.all()
    for i in codl:
        oll.append(i.pid)
    
    if(pid not in oll):
        tpid=pid
        trate=rate
        tqty = 1  
        itemttl = trate * tqty  
    
        print(tpid,trate)
        tod = Orderlog(pid = tpid , rate = trate , qty = tqty , itemttl = itemttl)
        db.session.add(tod)
        db.session.commit()
        return redirect('/products')
    else:
        toinc = Orderlog.query.filter_by(pid=pid).first()
        ttpid = toinc.pid
        ttrate = toinc.rate
        ttqty = toinc.qty + 1
        ttitemttl = ttrate*ttqty
        db.session.delete(toinc)
        db.session.commit()
        nodl = Orderlog(pid = ttpid , rate = ttrate , qty = ttqty , itemttl = ttitemttl)
        db.session.add(nodl)
        db.session.commit()
        return redirect('/products')


@app.route("/rfc/<int:pid>")
def rfc(pid):
    trfc=Orderlog.query.filter_by(pid=pid).first()
    db.session.delete(trfc)
    db.session.commit()
    
    return redirect('/products')  

@app.route("/cart")
def cart():
    cartt=Orderlog.query.all()
    pd=Product.query.all()
    total = 0
    lp=[]
    for x in cartt:
        total = x.itemttl + total
        lp.append(x.pid)
    session['lp'] = lp
    print(lp)
    

    return render_template('cart.html' , total = total , pd=pd ,cartt=cartt , lp=lp )


@app.route("/address")
def address():
    return render_template("address.html")



@app.route("/loginv" , methods = ['POST'])
def login_verify():
    temail = request.form['email']
    tpassw = request.form['password']
    print(temail , tpassw)
    udd = Userdata.query.all()
    for x in udd:
        if x.email == temail and x.passw == tpassw :
            return redirect ("/products")
        elif(x.email == temail and x.passw != tpassw ):
            return "inalid password please go back and try again"
    return "invalid email or password please go back and try again"

@app.route("/ud" , methods = ['GET'])
def showud():
    alllud = Userdata.query.all()
    
    return render_template("ud.html" , alllud = alllud)

@app.route("/signup")
def signup():
    return render_template("signup.html")

@app.route('/cod')
def cod():
   return render_template("address.html")

@app.route('/comp', methods = ['POST'])
def comp():
    name = request.form['name']
    address = request.form['address']
    mobile = request.form['mobile']
    lp = Orderlog.query.all()
    lpp = Product.query.all()
    lcc = Category.query.all()
    itms=[]
    ctms=[]
    lpid=[]
    qty = 0
    ottl=0
    tlpid=""
    for x in lpp:
        for y in lp:
            if int(x.pid) == int(y.pid):
                itms.append(x.pname)
                ctms.append(x.cid)
                lpid.append(x.pid)
    for q in lp:
        ottl = ottl + q.rate
        qty+=1
            
    for m in lpid:
        tlpid = tlpid + str(m)+","


    ittms =""
    for x in itms:
        ittms = ittms + x +"(1)" +","

    mmax = 0

    ood = Od.query.all()
    for x in ood:
        if int(x.orderid) > mmax :
            mmax = x.orderid
    cood=Corder.query.all()
    for y in cood:
        if y.orderid > mmax :
            mmax = y.orderid
    mmax+=1
    

    od1 = Od(orderid = mmax , name = name , address = address , mobile = mobile , item = ittms , pid = tlpid , qty = qty , ottl = ottl , payment_method = "cod")
    db.session.add(od1)
    db.session.commit()

    odl = Orderlog.query.all()
    for x in odl:
        db.session.delete(x)
        db.session.commit()

    

    return render_template('comp.html')

@app.route("/pod")
def pod():
    odd = Od.query.all()
    return render_template('od.html' , odd = odd)

@app.route("/convod/<int:orderid>")
def convod(orderid):
    tempod = Od.query.filter_by(orderid=orderid).first()
    codid = tempod.orderid
    codname = tempod.name
    codadd = tempod.address
    codmobile = tempod.mobile
    coditem =tempod.item
    codpid = tempod.pid
    codqty = tempod.qty
    codottl = tempod.ottl

        

    cod1 = Corder(orderid = codid , address = codadd , name = codname , item = coditem , pid = codpid , qty = codqty , ottl = codottl , mobile = codmobile)
    db.session.add(cod1)
    db.session.commit()

    db.session.delete(tempod)
    db.session.commit()


    return redirect("/pod")

@app.route('/cpod')
def cpod():
    codd = Corder.query.all()
    return render_template("cpod.html" , codd = codd)

@app.route("/dltc/<int:cid>")
def dltp(cid):
    todlt = Category.query.filter_by(cid=cid).first()
    db.session.delete(todlt)
    db.session.commit()
    todltp = Product.query.all()
    for x in todltp:
        if x.cid == str(cid) :
            db.session.delete(x)
            db.session.commit()

    return redirect("/addc")

@app.route("/dltp/<int:pid>")
def dltc(pid):
    todlt = Product.query.filter_by(pid=pid).first()
    db.session.delete(todlt)
    db.session.commit()

    return redirect("/addp")
@app.route('/sp' , methods =['POST'])
def srch():
    ke = request.form['srp']
    nfc = True
    nfp = True

    allc = Category.query.all()
    allp = Product.query.all()

    for c in allc:
        if ke == c.cname :
            nfc = False

    for p in allp:
        if ke == p.pname :
            nfp = False

    if nfc and nfp :
        return f"no such products or category found please go back and search again"
    
    return render_template('srchd.html' , ke = ke , allp = allp , allc = allc)

@app.route('/updtp/<int:pid>')
def updt(pid):
    session['upid']=pid
    toupdt = Product.query.filter_by(pid=pid).first()
    return render_template('updtp.html' , toupdt = toupdt)

@app.route('/updatep' , methods = ["POST"])
def updatep():
    toupid = session.get('upid')
    nmf = request.form['nmnfdt']
    nex = request.form['nexpdt']
    nr = request.form['nrate']
    

    toupdtt = Product.query.filter_by(pid=toupid).first()

    nrpid = toupdtt.pid
    nrcid = toupdtt.cid
    nrname = toupdtt.pname
    nrunit = toupdtt.unit

    if ((len(nmf)) == 0 ):
        nrmnfdt = toupdtt.mnfdt
    else:
        nrmnfdt = nmf

    if ((len(nex)) == 0 ):
        nrexpdt = toupdtt.expdt
    else:
        nrexpdt = nex

    if ((len(nr)) == 0 ):
        nrrate = toupdtt.rate
    else:
        nrrate = nr
    
    nrunit = toupdtt.unit

    nrp = Product(pid = nrpid , cid = nrcid , pname = nrname , mnfdt = nrmnfdt , expdt = nrexpdt , rate = nrrate , unit = nrunit)

    db.session.delete(toupdtt)
    db.session.commit()

    db.session.add(nrp)
    db.session.commit()

    session.clear()
    

    return redirect('/addp')




def main():
    # Start the Flask development server
    app.run(debug=True)

if __name__ == "__main__":
    main()



